# 部署

```bash
# 1. 解压
tar -xzf ops-data-query-mcp.tar.gz
cd ops-data-query-mcp

# 2. 启动（自动安装依赖）
./start.sh -d
```

## 环境变量

```bash
export MCP_USE_MOCK=true          # 启用 Mock 模式
export MCP_API_BASE_URL=xxx       # 自定义 API 地址
export HTTP_PROXY=http://proxy:8080  # 配置代理
```

## 验证

```bash
curl http://localhost:8000/health
```