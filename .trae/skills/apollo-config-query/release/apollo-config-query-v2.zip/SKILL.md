---
name: Apollo配置查询助手
description: 查询 Apollo 配置中心的配置数据（应用配置/Namespace/配置项/发布历史）。当用户询问 Apollo、配置、appid、namespace、配置项 key 等信息时调用。
version: 1.0.0
author: Skill Agent Team
---

# Apollo 配置查询助手

## 技能概述

本技能用于查询 Apollo 配置中心的配置数据，支持按应用、环境、集群、Namespace 等条件组合查询。

| 技能 ID | 功能描述 | 状态 | 触发关键词 |
|---------|----------|------|------------|
| apollo-config-search | 查询 Apollo 配置信息 | ✅ 可用 | Apollo、配置、appid、namespace、配置项、key |

---

## 路由规则

当用户输入包含「Apollo/配置/appid/namespace/配置项/key/配置中心」等关键词且意图为查询配置信息时，匹配 `apollo-config-search`。

**排他条件**：
- 如果用户明确提到"服务器"、"主机"、"机房"，应触发 `cmdb-server-query` 技能
- 如果用户明确提到"部署"、"发布记录"，应触发 `project-deployment-query` 技能

**业务处理**：参数映射、API 调用、输出格式化等业务逻辑由子技能 [apollo-config-search/SKILL.md](skills/apollo-config-search/SKILL.md) 负责。

---

## 输出格式

### 标准输出（配置列表模式 - 默认）

```markdown
## Apollo 配置查询结果

**查询条件**：{用户原始查询}

**应用**：{appId} | **环境**：{env} | **集群**：{clusterName} | **Namespace**：{namespaceName}

---

**结果摘要**：共查询到 N 个配置项

---

| 配置 Key | 值 | 说明 |
|----------|----|------|
| key1     | val1 | comment1 |
| key2     | val2 | comment2 |

---

💡 您可以说："查看发布历史"获取配置变更记录，或"搜索 timeout"按关键词过滤
```

### 发布历史输出（用户要求"查看发布历史"时）

```markdown
## Apollo 发布历史

**应用**：{appId} | **环境**：{env} | **Namespace**：{namespaceName}

---

| 版本 | 发布标题 | 发布人 | 发布时间 |
|------|----------|--------|----------|
| v1   | 2026-01配置更新 | zhangsan | 2026-01-15 10:30:00 |

---

💡 您可以说："查看版本详情"获取具体配置变更内容
```

---

## 上下文规则

多轮对话中保留以下参数（有效期 5 分钟）：
- 应用 ID（appId）
- 环境（env）
- 集群名称（clusterName）
- Namespace 名称（namespaceName）

**继承规则**：用户未明确指定参数时自动继承上下文。

| 用户输入 | 处理逻辑 |
|----------|----------|
| "查看发布历史" | 保持当前查询条件，切换到发布历史模式 |
| "搜索 {keyword}" | 保持当前查询条件，按 keyword 过滤配置项 |
| "查看 {appId} 的配置" | 更新 appId，保持其他参数 |
| "切换到 {env} 环境" | 更新 env，保持其他参数 |

**重置触发**：用户使用"新的/重新/重置"等关键词，或输入全新查询条件时重置上下文。

---

## 错误处理

### 场景一：缺少应用 ID

```markdown
我需要更多信息来完成查询。

请告诉我您想查询哪个应用的配置？

您也可以直接补充说："查询应用 rule-engine 的配置"
```

### 场景二：无查询结果

```markdown
## 查询结果

未查询到符合条件的配置项。

请检查应用 ID、环境、Namespace 是否正确。
```

### 场景三：API 调用失败

直接返回错误信息，不使用模拟数据：

```markdown
## 查询失败

**错误类型**：API 调用失败

**错误原因**：Apollo 服务暂不可用

**建议**：请稍后重试，如问题持续请联系管理员。
```

---

## 目录结构

```
apollo-config-query/
├── SKILL.md                              # 主技能入口（本文件）
├── registry/
│   └── skills.json                       # 技能注册中心
├── skills/
│   └── apollo-config-search/
│       ├── SKILL.md                      # Apollo 配置查询工具（含完整工具定义）
│       └── references/
│           ├── apollo-param-guide.md     # 参数转换完整指南
│           ├── app-options.md            # 应用可选值列表
│           └── namespace-options.md      # Namespace 可选值列表
└── _dev/                                 # 开发/打包相关（不参与打包）
    └── package.sh                        # 打包脚本
```

---

## 版本信息

- **版本**: 1.0.0
- **可用技能**: 1 个（apollo-config-search）
- **架构**: 纯配置 + 平台原生工具
- **设计模式**: 渐进式披露
