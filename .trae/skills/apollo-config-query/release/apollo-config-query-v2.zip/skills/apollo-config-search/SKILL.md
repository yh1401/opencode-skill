---
name: apollo-config-search
description: 查询 Apollo 配置中心的配置信息，支持按应用、环境、集群、Namespace 等多条件组合查询
version: 1.0.0
author: Skill Agent Team
---

# Apollo 配置查询技能

## 功能描述

本技能用于查询 Apollo 配置中心的配置数据，包括：
- 配置查询：按应用、环境、集群、Namespace 查询配置项
- 配置搜索：按 Key 关键词模糊搜索配置项
- 发布历史：查询配置的发布版本记录
- 应用列表：获取 Apollo 中所有应用列表

## 触发条件

当用户查询包含以下关键词时触发：
- Apollo、配置中心
- appid、应用配置
- namespace、配置项
- key、配置 key

**排他条件**：
- 如果用户明确提到"服务器"、"主机"、"机房"，应触发 `cmdb-server-query` 技能
- 如果用户明确提到"部署"、"发布记录"，应触发 `project-deployment-query` 技能

## 输入参数

### 必填参数

| 参数名 | 类型 | 说明 | 示例 |
|--------|------|------|------|
| appId | string | 应用 ID | "rule-engine" |

### 可选参数

| 参数名 | 类型 | 说明 | 默认值 | 可选值 |
|--------|------|------|--------|--------|
| env | string | 环境 | "PRO" | "DEV", "FAT", "UAT", "PRO" |
| clusterName | string | 集群名称 | "default" | - |
| namespaceName | string | Namespace 名称 | "application" | - |
| key | string | 配置项 Key（模糊匹配） | - | - |
| queryMode | string | 查询模式 | "config" | "config"=配置列表, "release"=发布历史, "apps"=应用列表 |

## 工具调用 Schema

```json
{
  "name": "apollo_config_search",
  "description": "查询Apollo配置中心的配置信息，支持按应用、环境、集群、Namespace等多条件组合查询",
  "parameters": {
    "type": "object",
    "properties": {
      "appId": {
        "type": "string",
        "description": "应用ID，如'rule-engine'"
      },
      "env": {
        "type": "string",
        "description": "环境，DEV=开发, FAT=测试, UAT=预发, PRO=生产",
        "enum": ["DEV", "FAT", "UAT", "PRO"]
      },
      "clusterName": {
        "type": "string",
        "description": "集群名称，默认为'default'"
      },
      "namespaceName": {
        "type": "string",
        "description": "Namespace名称，默认为'application'"
      },
      "key": {
        "type": "string",
        "description": "配置项Key（模糊匹配）"
      },
      "queryMode": {
        "type": "string",
        "description": "查询模式：config=配置列表, release=发布历史, apps=应用列表",
        "enum": ["config", "release", "apps"]
      }
    },
    "required": ["appId"]
  }
}
```

## 参数映射规则

### 环境映射

| 用户输入 | 目标参数 | 参数值 |
|----------|----------|--------|
| "开发环境"、"DEV"、"开发" | env | "DEV" |
| "测试环境"、"FAT"、"测试" | env | "FAT" |
| "预发环境"、"UAT"、"预发" | env | "UAT" |
| "生产环境"、"PRO"、"生产" | env | "PRO" |

### 集群映射

| 用户输入 | 目标参数 | 参数值 |
|----------|----------|--------|
| "默认集群"、"default" | clusterName | "default" |
| 其他集群名称 | clusterName | 原值传递 |

### Namespace 映射

| 用户输入 | 目标参数 | 参数值 |
|----------|----------|--------|
| "默认"、"application" | namespaceName | "application" |
| "数据库配置"、"datasource" | namespaceName | "datasource" |
| "Redis配置"、"redis" | namespaceName | "redis" |
| "日志配置"、"logging" | namespaceName | "logging" |
| "公共配置"、"common" | namespaceName | "common" |
| 其他 Namespace 名称 | namespaceName | 原值传递 |

> **完整 Namespace 列表**：常见 Namespace 见 [references/namespace-options.md](references/namespace-options.md)

### 查询模式映射

| 用户输入 | 目标参数 | 参数值 |
|----------|----------|--------|
| "查看配置"、"配置列表" | queryMode | "config" |
| "发布历史"、"变更记录" | queryMode | "release" |
| "应用列表"、"有哪些应用" | queryMode | "apps" |

### 应用 ID 映射

| 用户输入 | 目标参数 | 参数值 | 说明 |
|----------|----------|--------|------|
| 常见应用名称 | appId | 对应 ID | 见 [references/app-options.md](references/app-options.md) |
| 其他应用名称 | appId | 原值传递 | 模糊匹配 |

> **应用列表**：常见应用见 [references/app-options.md](references/app-options.md)

## API 接口

### 接口地址

| 环境 | ConfigService 地址 | Portal/OpenAPI 地址 |
|------|-------------------|-------------------|
| **本地开发** | `http://localhost:8080` | `http://localhost:8070` |
| **测试环境** | `http://test-apollo:8080` | `http://test-apollo:8070` |
| **生产环境** | `https://apollo.tech.ctseelink.cn` | `https://apollo.tech.ctseelink.cn` |

### 认证方式

**ConfigService 直接调用**（推荐，无需认证）：
```
Content-Type: application/json;charset=UTF-8
```

**OpenAPI 调用**（需要 Token）：
```
Authorization: {Apollo OpenAPI Token}
Content-Type: application/json;charset=UTF-8
```

### 接口列表

#### 1. 获取 Namespace 配置（queryMode=config）

**方式一：ConfigService 直接调用**（推荐，无需认证）
```
GET /configs/{appId}/{clusterName}/{namespaceName}
```

**响应格式**：
```json
{
  "appId": "SampleApp",
  "cluster": "default",
  "namespaceName": "application",
  "configurations": {
    "timeout": "100",
    "max.retry": "3"
  },
  "releaseKey": "20161009155425-d3a0749c6e20bc15"
}
```

**方式二：OpenAPI 调用**（需要认证）
```
GET /openapi/v1/envs/{env}/apps/{appId}/clusters/{clusterName}/namespaces/{namespaceName}
```

**响应格式**：
```json
{
  "appId": "rule-engine",
  "clusterName": "default",
  "namespaceName": "application",
  "format": "properties",
  "items": [
    {
      "key": "timeout",
      "value": "3000",
      "comment": "超时时间配置",
      "dataChangeLastModifiedTime": "2026-01-15 10:30:00"
    }
  ]
}
```

#### 2. 获取发布历史（queryMode=release）

**OpenAPI 调用**
```
GET /openapi/v1/envs/{env}/apps/{appId}/clusters/{clusterName}/namespaces/{namespaceName}/releases
```

**响应格式**：
```json
{
  "appId": "rule-engine",
  "clusterName": "default",
  "namespaceName": "application",
  "releases": [
    {
      "id": 1,
      "releaseTitle": "2026-01配置更新",
      "releaseComment": "更新超时时间",
      "releasedBy": "zhangsan",
      "releaseTime": "2026-01-15 10:30:00"
    }
  ]
}
```

#### 3. 获取应用列表（queryMode=apps）

**OpenAPI 调用**
```
GET /openapi/v1/apps
```

**响应格式**：
```json
{
  "appId": "rule-engine",
  "name": "规则引擎平台",
  "orgName": "技术中台",
  "orgId": "org-001"
}
```

#### 4. 搜索配置项（queryMode=search）

**ConfigService 直接调用**（推荐）
```
GET /configs/{appId}/{clusterName}/{namespaceName}?q={keyword}
```

> **提示**：ConfigService 接口不支持直接搜索，搜索功能需要在获取配置后在本地进行过滤。

### 接口选择策略

| 场景 | 推荐接口 | 原因 |
|------|---------|------|
| 查询配置项列表 | ConfigService `/configs/{appId}/{cluster}/{namespace}` | 无需认证，响应快 |
| 获取完整配置详情（含注释） | OpenAPI `/openapi/v1/envs/{env}/apps/...` | 返回完整元数据 |
| 查询发布历史 | OpenAPI `/openapi/v1/envs/{env}/apps/.../releases` | ConfigService 不提供 |
| 查询应用列表 | OpenAPI `/openapi/v1/apps` | ConfigService 不提供 |
| 本地开发测试 | ConfigService | 无需配置 Token |
| 生产环境 | OpenAPI | 需要权限控制 |

### 响应字段说明

#### 配置项字段

| 字段 | 类型 | 说明 |
|------|------|------|
| key | string | 配置项 Key |
| value | string | 配置项值 |
| comment | string | 配置项说明 |
| dataChangeLastModifiedTime | string | 最后修改时间 |

#### 发布历史字段

| 字段 | 类型 | 说明 |
|------|------|------|
| id | integer | 版本 ID |
| releaseTitle | string | 发布标题 |
| releaseComment | string | 发布说明 |
| releasedBy | string | 发布人 |
| releaseTime | string | 发布时间 |

## 输出格式

### 标准输出（配置列表模式 - 默认）

```
## Apollo 配置查询结果

**查询条件**：{用户原始查询}

**应用**：rule-engine | **环境**：PRO | **集群**：default | **Namespace**：application

---

**结果摘要**：共查询到 5 个配置项

---

| 配置 Key | 值 | 说明 |
|----------|----|------|
| timeout | 3000 | 超时时间配置 |
| max.retry | 3 | 最大重试次数 |
| pool.size | 20 | 连接池大小 |

---

💡 您可以说：
- "查看发布历史" - 获取配置变更记录
- "搜索 timeout" - 按关键词过滤配置项
- "查看 datasource 配置" - 切换到其他 Namespace
```

### 发布历史输出

```
## Apollo 发布历史

**应用**：rule-engine | **环境**：PRO | **Namespace**：application

---

| 版本 | 发布标题 | 发布人 | 发布时间 |
|------|----------|--------|----------|
| v3 | 2026-01配置更新 | zhangsan | 2026-01-15 10:30:00 |
| v2 | 2025-12连接池优化 | lisi | 2025-12-10 14:00:00 |
| v1 | 初始配置 | admin | 2025-11-01 09:00:00 |
```

### 应用列表输出

```
## Apollo 应用列表

---

| AppId | 应用名称 | 部门 |
|-------|----------|------|
| rule-engine | 规则引擎平台 | 技术中台 |
| data-platform | 数据中台 | 数据中心 |
| ai-gateway | AI网关 | AI平台 |
```

## 完整调用示例

### 示例 1：查询应用配置

**用户输入**："查询 rule-engine 在生产环境的配置"

**工具调用**：
```json
{
  "tool_name": "apollo_config_search",
  "parameters": {
    "appId": "rule-engine",
    "env": "PRO",
    "queryMode": "config",
    "namespaceName": "application"
  }
}
```

**API 请求**：
```
GET /openapi/v1/envs/PRO/apps/rule-engine/clusters/default/namespaces/application
Authorization: {token}
```

**API 响应**：
```json
{
  "appId": "rule-engine",
  "clusterName": "default",
  "namespaceName": "application",
  "items": [
    {
      "key": "timeout",
      "value": "3000",
      "comment": "超时时间配置"
    },
    {
      "key": "max.retry",
      "value": "3",
      "comment": "最大重试次数"
    }
  ]
}
```

**最终输出**：
```
## Apollo 配置查询结果

**查询条件**：查询 rule-engine 在生产环境的配置

**应用**：rule-engine | **环境**：PRO | **集群**：default | **Namespace**：application

---

**结果摘要**：共查询到 2 个配置项

---

| 配置 Key | 值 | 说明 |
|----------|----|------|
| timeout | 3000 | 超时时间配置 |
| max.retry | 3 | 最大重试次数 |

---

💡 您可以说：
- "查看发布历史" - 获取配置变更记录
- "搜索 timeout" - 按关键词过滤配置项
```

### 示例 2：搜索特定配置项

**用户输入**："查一下 rule-engine 的 timeout 配置"

**工具调用**：
```json
{
  "tool_name": "apollo_config_search",
  "parameters": {
    "appId": "rule-engine",
    "env": "PRO",
    "queryMode": "config",
    "namespaceName": "application",
    "key": "timeout"
  }
}
```

**最终输出**：
```
## Apollo 配置查询结果

**查询条件**：查一下 rule-engine 的 timeout 配置

**应用**：rule-engine | **环境**：PRO | **Namespace**：application

---

**结果摘要**：搜索关键词 "timeout"，匹配到 1 个配置项

---

| 配置 Key | 值 | 说明 |
|----------|----|------|
| timeout | 3000 | 超时时间配置 |
```

### 示例 3：查询发布历史

**用户输入**："rule-engine 的配置变更记录"

**工具调用**：
```json
{
  "tool_name": "apollo_config_search",
  "parameters": {
    "appId": "rule-engine",
    "env": "PRO",
    "queryMode": "release",
    "namespaceName": "application"
  }
}
```

**最终输出**：
```
## Apollo 发布历史

**应用**：rule-engine | **环境**：PRO | **Namespace**：application

---

| 版本 | 发布标题 | 发布人 | 发布时间 |
|------|----------|--------|----------|
| v3 | 2026-01配置更新 | zhangsan | 2026-01-15 10:30:00 |
| v2 | 2025-12连接池优化 | lisi | 2025-12-10 14:00:00 |
| v1 | 初始配置 | admin | 2025-11-01 09:00:00 |
```

## 错误处理

### 错误场景 1：缺少应用 ID

**输入**："查询 Apollo 配置"

**输出**：
```
我需要更多信息来完成查询。

请告诉我您想查询哪个应用的配置？

您也可以直接补充说："查询应用 rule-engine 的配置"
```

### 错误场景 2：API 调用失败

**输出**：
```
## 查询失败

**错误类型**：API 调用失败

**错误原因**：Apollo 服务暂不可用

**建议**：
1. 检查 Apollo 服务是否正常
2. 确认 API Token 是否有效
3. 如问题持续，请联系管理员
```

### 错误场景 3：无查询结果

**输入**："查询应用 nonexistent-app 的配置"

**输出**：
```
## 查询结果

未查询到符合条件的配置项。

请检查应用 ID 是否正确。
可查询的应用列表见：references/app-options.md
```
