---
name: server-public-ip-query
description: 查询服务器公网 IP 信息，包括公网 IP 地址、内网 IP、带宽大小、带宽类型、网络类型、负载均衡器配置等。支持按机房、IP、公网 IP 等条件查询。
version: 2.0.0
author: Skill Agent Team
---

# 服务器公网 IP 查询技能

## 功能描述

本技能用于查询服务器的公网网络信息，包括：
- 公网 IP 地址：IPv4 和 IPv6
- 内网 IP 地址
- 带宽信息：带宽大小、带宽类型、计费类型
- 虚 IP（VIP）配置
- 机房位置信息

## 触发条件

当用户查询包含以下关键词时触发：
- 公网 IP、外网 IP、出口 IP
- 服务器带宽、带宽大小、带宽类型
- 网络类型、网络配置

**排他条件**：
- 如果用户查询的是服务器基本配置信息（不涉及公网 IP），应触发 `cmdb-server-query` 技能

## 输入参数

### 必填参数

无

### 可选参数

| 参数名 | 类型 | 说明 | 默认值 | 可选值 |
|--------|------|------|--------|--------|
| id | string | 记录 ID | - | - |
| node | string | 机房位置 | - | 如 "云公司->贵州" |
| ip | string | 内网 IP 地址 | - | - |
| publicIp | string | 公网 IP 地址 | - | - |
| netType | integer | 网络类型 | - | 1, 2 |
| currentPage | integer | 页码 | 1 | ≥1 |
| pageSize | integer | 每页条数 | 40 | 1~100 |

## 工具调用 Schema

```json
{
  "name": "server_public_ip_query",
  "description": "查询服务器公网IP信息，包括公网IP、内网IP、带宽、带宽类型、网络类型等",
  "parameters": {
    "type": "object",
    "properties": {
      "id": {
        "type": "string",
        "description": "记录ID"
      },
      "node": {
        "type": "string",
        "description": "机房位置，如'云公司->贵州'"
      },
      "ip": {
        "type": "string",
        "description": "内网IP地址"
      },
      "publicIp": {
        "type": "string",
        "description": "公网IP地址"
      },
      "netType": {
        "type": "integer",
        "description": "网络类型",
        "enum": [1, 2]
      },
      "currentPage": {
        "type": "integer",
        "description": "页码",
        "minimum": 1
      },
      "pageSize": {
        "type": "integer",
        "description": "每页条数",
        "minimum": 1,
        "maximum": 100
      }
    },
    "required": []
  }
}
```

## 参数映射规则

### 机房节点映射

| 用户输入 | 目标参数 | 参数值 |
|----------|----------|--------|
| "贵州"、"贵阳"、"贵州机房" | node | "云公司->贵州" |
| "北京"、"北京机房" | node | "云公司->北京" |
| "上海"、"上海机房" | node | "省公司->上海" |
| "广州"、"广州机房" | node | "云公司->广州" |

### IP 类型识别规则

| 用户输入模式 | 目标参数 | 提取规则 |
|--------------|----------|----------|
| "查 192.168.x.x 的公网 IP" | ip | 提取内网 IP |
| "查 113.x.x.x 的信息" | publicIp | 提取公网 IP |
| "查询公网 IP" | - | 不指定，返回所有 |

### 数量词识别规则

| 用户输入 | 对应的 pageSize |
|----------|----------------|
| "最近的"、"最新的" | 10 |
| "所有"、"全部" | 100 |
| "一些"、"几条" | 40 (默认) |

## API 接口

### 接口地址

**生产环境**：POST https://oss.tech.ctseelink.cn/a/cmdb/serverPublicIp/

### 请求格式

```json
{
  "node": "云公司->贵州",
  "currentPage": 1,
  "pageSize": 40
}
```

### 请求参数说明

| 参数名 | 说明 |
|--------|------|
| id | 记录 ID |
| node | 机房位置 |
| ip | 内网 IP 地址 |
| publicIp | 公网 IP 地址 |
| netType | 网络类型 |
| currentPage | 页码 |
| pageSize | 每页条数 |

### 参数映射（用户输入 → API 参数）

| 用户参数 | API 参数 |
|----------|----------|
| id | id |
| node | node |
| ip | ip |
| publicIp | publicIp |
| netType | netType |
| page | currentPage |
| pageSize | pageSize |

### 响应格式

```json
{
  "code": 200,
  "message": "success",
  "data": {
    "records": [
      {
        "publicIp": "113.12.13.14",
        "publicIpv6": "2409:8c00:1234:5678::1",
        "ip": "192.168.7.101",
        "vip": "",
        "node": "云公司->贵州",
        "bandwidth": "100Mbps",
        "bandwidthType": "独享",
        "billingType": "按带宽"
      }
    ],
    "total": 100,
    "current": 1,
    "size": 40,
    "pages": 3
  }
}
```

### 响应字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| code | integer | 状态码，200 表示成功 |
| message | string | 响应消息 |
| data | object | 响应数据体 |
| data.records | array | 公网 IP 记录列表 |
| data.total | integer | 总记录数 |
| data.current | integer | 当前页码 |
| data.size | integer | 每页条数 |
| data.pages | integer | 总页数 |

### records 中的每条记录

| 字段 | 类型 | 说明 |
|------|------|------|
| publicIp | string | 公网 IP 地址 |
| publicIpv6 | string | 公网 IPv6 地址 |
| ip | string | 内网 IP 地址 |
| vip | string | 虚 IP |
| node | string | 机房位置 |
| bandwidth | string | 带宽，如 "100Mbps" |
| bandwidthType | string | 带宽类型，如 "独享"、"共享" |
| billingType | string | 计费类型，如 "按带宽"、"按流量计费" |

## 输出格式

### 标准输出

```
## 公网 IP 查询结果

**查询条件**：{用户原始查询}

**匹配技能**：服务器公网 IP 查询

**查询参数**：{"node":"云公司->贵州","pageSize":40}

---

**结果摘要**：共查询到 N 条公网 IP 记录

---

| 公网 IP | 内网 IP | 机房 | 带宽 | 带宽类型 | 计费类型 |
|---------|---------|------|------|----------|----------|
| 113.12.13.14 | 192.168.7.101 | 云公司->贵州 | 100Mbps | 独享 | 按带宽 |
| ... | ... | ... | ... | ... | ... |

---

**说明**：数据来源于 CMDB 系统。
```

### 降级输出（API 失败时）

```
## 公网 IP 查询结果

> ⚠️ 提示：API 接口调用失败，已切换为模拟数据

**查询条件**：{用户原始查询}

**匹配技能**：服务器公网 IP 查询

**查询参数**：{"node":"云公司->贵州","pageSize":40}

---

**结果摘要**：共查询到 N 条公网 IP 记录（模拟数据）

---

| 公网 IP | 内网 IP | 机房 | 带宽 | 带宽类型 | 计费类型 |
|---------|---------|------|------|----------|----------|
| 113.12.13.14 | 192.168.7.101 | 云公司->贵州 | 100Mbps | 独享 | 按带宽 |
| ... | ... | ... | ... | ... | ... |

---

**说明**：当前显示的是模拟数据，真实数据需要部署服务可用时才能获取。
```

## 完整调用示例

### 示例 1：按机房查询

**用户输入**："查询贵州机房的公网 IP"

**工具调用**：
```json
{
  "tool_name": "server_public_ip_query",
  "parameters": {
    "node": "云公司->贵州",
    "currentPage": 1,
    "pageSize": 40
  }
}
```

**API 请求**：
```json
{
  "node": "云公司->贵州",
  "currentPage": 1,
  "pageSize": 40
}
```

**API 响应**：
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "records": [
      {
        "publicIp": "113.12.13.14",
        "publicIpv6": "2409:8c00:1234:5678::1",
        "ip": "192.168.7.101",
        "vip": "",
        "node": "云公司->贵州",
        "bandwidth": "100Mbps",
        "bandwidthType": "独享",
        "billingType": "按带宽"
      }
    ],
    "total": 100,
    "current": 1,
    "size": 40,
    "pages": 3
  }
}
```

**最终输出**：
```
## 公网 IP 查询结果

**查询条件**：查询贵州机房的公网 IP

**匹配技能**：服务器公网 IP 查询

**查询参数**：{"node":"云公司->贵州","pageSize":40}

---

**结果摘要**：共查询到 100 条公网 IP 记录

---

| 公网 IP | 内网 IP | 机房 | 带宽 | 带宽类型 | 计费类型 |
|---------|---------|------|------|----------|----------|
| 113.12.13.14 | 192.168.7.101 | 云公司->贵州 | 100Mbps | 独享 | 按带宽 |
| ... | ... | ... | ... | ... | ... |

---

**说明**：数据来源于 CMDB 系统。
```

### 示例 2：按内网 IP 查询

**用户输入**："查 192.168.7.101 的公网 IP"

**工具调用**：
```json
{
  "tool_name": "server_public_ip_query",
  "parameters": {
    "ip": "192.168.7.101"
  }
}
```

**API 请求**：
```json
{
  "ip": "192.168.7.101"
}
```

**API 响应**：
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "records": [
      {
        "publicIp": "113.12.13.14",
        "ip": "192.168.7.101",
        "node": "云公司->贵州",
        "bandwidth": "100Mbps",
        "bandwidthType": "独享"
      }
    ],
    "total": 1,
    "current": 1,
    "size": 40,
    "pages": 1
  }
}
```

**最终输出**：
```
## 公网 IP 查询结果

**查询条件**：查 192.168.7.101 的公网 IP

**匹配技能**：服务器公网 IP 查询

**查询参数**：{"ip":"192.168.7.101"}

---

**结果摘要**：共查询到 1 条公网 IP 记录

---

| 公网 IP | 内网 IP | 机房 | 带宽 | 带宽类型 |
|---------|---------|------|------|----------|
| 113.12.13.14 | 192.168.7.101 | 云公司->贵州 | 100Mbps | 独享 |

---

**说明**：数据来源于 CMDB 系统。
```

## 错误处理

### 错误场景 1：参数格式错误

**输入**："查询无效的 IP 地址"

**输出**：
```
## 查询失败

**错误类型**：参数格式错误

**错误原因**：IP 地址格式不正确

**建议**：请输入有效的 IP 地址，如"192.168.7.101"或"113.12.13.14"
```

### 错误场景 2：API 调用失败

**输出**：
```
## 查询失败

**错误类型**：网络错误

**错误原因**：CMDB 服务响应失败，请稍后重试

**建议**：
1. 检查网络连接
2. 稍后重新查询
3. 如问题持续，请联系管理员
```

### 错误场景 3：无查询结果

**输入**："查询不存在的 IP"

**输出**：
```
## 查询结果

**查询条件**：查询不存在的 IP

**匹配技能**：服务器公网 IP 查询

**查询参数**：{"publicIp":"999.999.999.999","pageSize":40}

---

**结果摘要**：未查询到符合条件的公网 IP 记录

---

**说明**：当前系统中不存在该 IP 的公网配置信息。
```

## Mock 数据（API 降级备用）

当 API 不可用时，使用以下模拟数据返回：

```json
{
  "code": 200, "message": "success",
  "data": {
    "records": [
      {
        "publicIp": "113.12.13.14", "publicIpv6": "2409:8c00:1234:5678::1",
        "ip": "192.168.7.101", "vip": "", "node": "云公司->贵州",
        "bandwidth": "100Mbps", "bandwidthType": "独享", "billingType": "按带宽"
      },
      {
        "publicIp": "113.12.13.15", "publicIpv6": "2409:8c00:1234:5678::2",
        "ip": "192.168.7.102", "vip": "10.0.0.1", "node": "云公司->贵州",
        "bandwidth": "50Mbps", "bandwidthType": "共享", "billingType": "按流量计费"
      },
      {
        "publicIp": "114.25.36.47", "publicIpv6": "",
        "ip": "192.168.8.101", "vip": "", "node": "省公司->上海",
        "bandwidth": "200Mbps", "bandwidthType": "独享", "billingType": "按带宽"
      }
    ],
    "total": 3, "size": 40, "current": 1, "pages": 1
  }
}
```
