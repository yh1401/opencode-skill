# -*- coding: utf-8 -*-
"""replica_reconcile.py — 副本对账脚本（批量工具串配 Bug 的过渡措施）

用法:
  python replica_reconcile.py <spec_spill.json> <avail_spill.json> [scope.json]

输入: 两条即时查询的 spill 文件（相对路径相对本脚本所在目录）
  spec:  sum by (namespace, deployment, cluster, env) (kube_deployment_spec_replicas{cmdb_node=~"...|...", env="生产"})
  avail: sum by (namespace, deployment, cluster, env) (kube_deployment_status_replicas_available{...})
  scope: 可选，-dep 应用名单 JSON（数组）。不传则全量。

关键: by 子句必须保留 deployment（+cluster+env）——这是序列唯一身份。
输出:
  0) 键冲突检查（重复键 = 串配 Bug 指纹，出现即说明聚合口径错误）
  1) 真实缺口清单 (spec>avail)
  2) 单副本清单 (spec=1)，生产/灰度命名空间拆分
  3) spec=0 下线清单
  4) 单侧序列（仅一侧存在 → 数据不足，不得静默丢弃）
"""
import json, os, re, sys, collections

here = os.path.dirname(os.path.abspath(__file__))
LABEL_RE = re.compile(r'(\w+)="((?:[^"\\]|\\.)*)"')
INST_RE = re.compile(r'^\s*(\w+)?\{(.*)\}\s*=>\s*(-?[\d.]+(?:[eE][+-]?\d+)?)\s*@\[[^\]]+\]\s*$')

def load_spill(rel):
    path = rel if os.path.isabs(rel) else os.path.join(here, rel)
    with open(path, encoding='utf-8') as f:
        d = json.load(f)
    rows = []
    for line in (d.get('result') or '').split('\n'):
        m = INST_RE.match(line)
        if not m:
            continue
        try:
            v = float(m.group(3))
        except Exception:
            v = None
        rows.append((dict(LABEL_RE.findall(m.group(2))), v))
    return rows

def key(l):
    return (l.get('namespace'), l.get('deployment'), l.get('cluster'), l.get('env'))

spec_rows = load_spill(sys.argv[1])
avail_rows = load_spill(sys.argv[2])
scope = None
if len(sys.argv) > 3:
    scope_path = sys.argv[3]
    scope = set(json.load(open(scope_path if os.path.isabs(scope_path) else os.path.join(here, scope_path), encoding='utf-8')))

# 0) 键冲突检查
for name, rows in (('spec', spec_rows), ('avail', avail_rows)):
    keys = [key(l) for l, v in rows]
    dup = {k: c for k, c in collections.Counter(keys).items() if c > 1}
    print(f'[{name}] rows={len(rows)} unique_keys={len(set(keys))} collisions={len(dup)}')
    for k in list(dup)[:5]:
        print('   DUP:', k)

spec_map = {key(l): v for l, v in spec_rows}
avail_map = {key(l): v for l, v in avail_rows}

only_spec = sorted(set(spec_map) - set(avail_map))
only_avail = sorted(set(avail_map) - set(spec_map))
print(f'only_spec={len(only_spec)} only_avail={len(only_avail)}')
for k in only_spec[:10]:
    print('  only_spec', k, spec_map[k])
for k in only_avail[:10]:
    print('  only_avail', k, avail_map[k])

def in_scope(k):
    return scope is None or k[1] in scope

gaps, single, offline, ok = [], [], [], 0
for k, s in spec_map.items():
    if not in_scope(k):
        continue
    a = avail_map.get(k)
    if a is None:
        continue
    if s == 0:
        offline.append((k, a))
    elif s < 2:
        single.append((k, s, a))
    elif s > a:
        gaps.append((k, s, a))
    else:
        ok += 1

print(f'\n== in-scope summary: ok={ok} gaps={len(gaps)} single_series={len(single)} offline_series={len(offline)} ==')
print('== 真实缺口 (spec>avail) ==')
for k, s, a in sorted(gaps, key=lambda x: -(x[1] - x[2])):
    print(f'  {k[0]}/{k[1]} [{k[2]}] {s}/{a} gap={int(s - a)}')
print('== 单副本 (spec=1) ==')
print(f'  series={len(single)} apps={len({k[1] for k, s, a in single})}')
prod_single = [x for x in single
               if not any(x[0][0].endswith(sfx) for sfx in ('-gray', '-test', '-dev', '-pre'))]
print(f'  prod-ns series={len(prod_single)} apps={len({k[1] for k, s, a in prod_single})}')
for k, s, a in sorted(prod_single):
    print(f'    {k[0]}/{k[1]} [{k[2]}] {s}/{a}')
print('== 下线 (spec=0) ==')
print(f'  series={len(offline)} apps={len({k[1] for k, a in offline})}')
